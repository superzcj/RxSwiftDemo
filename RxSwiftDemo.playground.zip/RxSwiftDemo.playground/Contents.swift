import UIKit

//protocol Observer {
//    func update(mes: String)
//}
//
//class Subject {
//    var observers: Array<Observer> = []
//    func regist(observer: Observer) {
//        self.observers.append(observer)
//    }
//
//    func notice(msg: String) {
//        for item in self.observers {
//            item.update(mes: msg)
//        }
//    }
//}



//Observer pattern
//protocol Observer {
//    func update(message: String)
//}
//
//class Subject {
//    var observers: Array<Observer> = []
//
//    func register(observer:Observer) {
//        self.observers.append(observer)
//    }
//
//    func notify(message: String) {
//        for observer in observers {
//            observer.update(message: message)
//        }
//    }
//}
//class Observer1: Observer {
//    func update(message: String) {
//        print("Observer1: " + message)
//    }
//}
//
//class Observer2: Observer {
//    func update(message: String) {
//        print("Observer2: " + message)
//    }
//}
//
//let subject = Subject()
//let observer1 = Observer1()
//let observer2 = Observer2()
//
//subject.register(observer: observer1)
//subject.register(observer: observer2)
//
//subject.notify(message: "zcj")

//typealias EventHandler = (String) -> Void
//let e = {(msg) in
//    print(msg)
//}
//e("zcj")


//simple 1: Observer
typealias EventHandler = (String) -> Void

func myObservable(eventHandler: EventHandler) {
    eventHandler("zcj")
    eventHandler("hello")
    eventHandler("world")
}

let eventHandler : EventHandler = {(value) -> Void in
    print(value)
}
myObservable(eventHandler: eventHandler)


//simple 2
//class Observer {
//
//    typealias EventHandler = (String) -> Void
//
//    private let _eventHandler : EventHandler
//    init(eventHandler: @escaping EventHandler) {
//        self._eventHandler = eventHandler
//    }
//
//    func next(value: String) {
//        self._eventHandler(value)
//    }
//}
//
//func myObservable(handle: @escaping (String) -> Void) {
//    let observer = Observer(eventHandler: handle)
//    observer.next(value: "zcj")
//}
//
//
//
//
//
//let closure = {(value: String) -> Void in
//    print(value)
//}
//myObservable(handle: closure)

//simple 3
//
//typealias EventHandler = (String) -> Void
//typealias SubscribeHandler = (Observer) -> Void
//
//class Observer {
//
//    private let _eventHandler : EventHandler
//    init(eventHandler: @escaping EventHandler) {
//        self._eventHandler = eventHandler
//    }
//
//    func next(value: String) {
//        self._eventHandler(value)
//    }
//}
//
//class Observable {
//
//    private let subscribeHandler: SubscribeHandler
//
//    public init(_ subscribeHandler: @escaping SubscribeHandler) {
//        self.subscribeHandler = subscribeHandler
//    }
//
//    public func subscribe(eventHandler: @escaping EventHandler) {
//        let observer = Observer(eventHandler: eventHandler)
//        self.subscribeHandler(observer)
//    }
//}
//
//let observable = Observable{(observer) -> Void in
//    observer.next(value: "zcj")
//}
//observable.subscribe{(value) in
//    print(value)
//}

//simple 4

//typealias EventHandler = (String) -> Void
//typealias SubscribeHandler = (Observer) -> Void
//
//class Observer {
//
//    private let _eventHandler : EventHandler
//    init(eventHandler: @escaping EventHandler) {
//        self._eventHandler = eventHandler
//    }
//
//    func next(value: String) {
//        self._eventHandler(value)
//    }
//}
//
//class Observable {
//
//    private let subscribeHandler: SubscribeHandler
//
//    public init(_ subscribeHandler: @escaping SubscribeHandler) {
//        self.subscribeHandler = subscribeHandler
//    }
//
//    public func subscribe(eventHandler: @escaping EventHandler) {
//        let observer = Observer(eventHandler: eventHandler)
//        self.subscribeHandler(observer)
//    }
//}
//
//func map(source: Observable, transform: @escaping (_ value: String) -> String) -> Observable {
//    return Observable({ (observer) in
//        let closure = {(value: String) -> Void in
//            let transformedValue = transform(value)
//            observer.next(value: transformedValue)
//        }
//        source.subscribe(eventHandler: closure)
//    })
//}
//
//let observable = Observable{(observer) -> Void in
//    observer.next(value: "zcj")
//}
//
//let closure = {(value: String) -> Void in
//    print(value)
//    print(value)
//    print(value)
//}
//
//map(source: observable) { (value) -> String in
//    return "hi " + value + " ...."
//}.subscribe(eventHandler: closure)
